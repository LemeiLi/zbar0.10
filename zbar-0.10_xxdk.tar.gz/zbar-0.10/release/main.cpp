/***************************************************** 
 程序功能 -- 二维码图片检测和解码 
 用的是opencv3版本的函数用到了 
	1 边缘检测Sobel 
    2 二值化threshold 
    3 形态学操作膨胀腐蚀 erode dilate 
    4 轮廓寻找findContours 
    5 二维码解码 
******************************************************/  

#include <cv.h>
#include <zbar.h>
#include <time.h>  
#include <stdio.h>  
#include <iostream>  
#include <highgui.h>
#include <opencv2/opencv.hpp>   
#include <opencv2/core/mat.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
  
using namespace std;  
using namespace cv;  
using namespace zbar;  
  
#define FLOAT 10  

int main(int argc, char *argv[])  
{  
    // 
    // 加载原图  
	//
    IplImage *srcImage = cvLoadImage(argv[1], 1);  
    //cvNamedWindow("source picture",0);  
    //cvShowImage("source picture",image);  
  
	//
    // 测时  
	//
    clock_t start, finish;  
    double duration;  
    start = clock();  
	// 
    // 转变为灰度图  
	// 
    IplImage *Grayimage = cvCreateImage(cvGetSize(srcImage), IPL_DEPTH_8U, 1);  
    cvCvtColor(srcImage, Grayimage, CV_BGR2GRAY);  

	Mat imageGray;  
	Mat image_res = imread(argv[1]);
    cvtColor(image_res, imageGray, CV_RGB2GRAY);  

    cvNamedWindow("0. Grayimage", 0);  
    cvShowImage("0. Grayimage", Grayimage);  
 
	//
    // 通过sobel算子对图片进行横竖向边缘检测,输入图像是8位时，输出必须是16位，然后再将图像转变成8位深   
	//
    IplImage *sobel = cvCreateImage(cvGetSize(Grayimage), IPL_DEPTH_16S, 1);  
    cvSobel(Grayimage, sobel, 0, 2, 7);  
    IplImage *temp = cvCreateImage(cvGetSize(sobel), IPL_DEPTH_8U, 1);  
    cvConvertScale(sobel, temp, 0.002, 0);  
    cvNamedWindow("1.x sobel convert", 0);  
    cvShowImage("1.x sobel convert", temp);  
	
    sobel = cvCreateImage(cvGetSize(Grayimage), IPL_DEPTH_16S, 1);  
    cvSobel(Grayimage, sobel, 2, 0, 7);  
    temp = cvCreateImage(cvGetSize(sobel), IPL_DEPTH_8U, 1);  
    cvConvertScale(sobel, temp, 0.002, 0);  
    cvNamedWindow("1.y sobel convert", 0);  
    cvShowImage("1.y sobel convert", temp);  
  
  
    //对图像进行二值化处理  
    IplImage *threshold = cvCreateImage(cvGetSize(temp), IPL_DEPTH_8U, 1);  
    cvThreshold(temp,threshold, 13, 100, CV_THRESH_BINARY/*| CV_THRESH_OTSU*/);  
    //cvThreshold(temp, threshold, 0, 255, CV_THRESH_OTSU+CV_THRESH_BINARY);   
  
    cvNamedWindow("2. threshold", 0);  
    cvShowImage("2. threshold", threshold);  
  
    //自定义1*3的核进行X方向的膨胀腐蚀    
    IplImage *erode_dilate = cvCreateImage(cvGetSize(threshold), IPL_DEPTH_8U, 1);  
    IplConvKernel* kernal = cvCreateStructuringElementEx(3, 1, 1, 0, CV_SHAPE_RECT);  
    cvDilate(threshold, erode_dilate, kernal, 15);   // X方向膨胀连通数字  
    cvErode(erode_dilate, erode_dilate, kernal, 6);  // X方向腐蚀去除碎片  
    cvDilate(erode_dilate, erode_dilate, kernal, 1); // X方向膨胀回复形态  
  
    //自定义3*1的核进行Y方向的膨胀腐蚀  
    kernal = cvCreateStructuringElementEx(1,3, 0, 1, CV_SHAPE_RECT);  
    //cvDilate(erode_dilate, erode_dilate, kernal, 5);  
    cvErode(erode_dilate, erode_dilate, kernal, 2); // Y方向腐蚀去除碎片  
    cvDilate(erode_dilate, erode_dilate, kernal, 6);// 回复形态  
    cvNamedWindow("3. erode_dilate",0);  
    cvShowImage("3. erode_dilate",erode_dilate);  
  
    // 图形检测  
    IplImage* copy = cvCloneImage(erode_dilate); // 直接把erode_dilate的数据复制给copy  
    IplImage* copy1 = cvCloneImage(srcImage);    // 直接把image的数据复制给copy1  
    CvMemStorage* storage = cvCreateMemStorage();  
    CvSeq* contours;  
    cvFindContours(copy, storage, &contours);    // 统计轮廓
    int i=0,k=0,j=0;  
    CvRect RECT[100];  
    CvRect Rect[100];  
      
    while(contours != NULL)  
    {  
        //绘制轮廓的最小外接矩形,如果满足条件，将该矩形绘制在显示图片dst  
        /* 
           矩形要求: 
               1.宽度与高度的比值在(2,5)之间 
               2.面积大于图像的 1/20000 
               3.y轴的位置在图像高度减去50以下 
        */  
        CvRect rect = cvBoundingRect(contours,  1);  //cvBoundingRect计算点集的最外面（up-right）矩形边界。  
        if(rect.width/rect.height > 0.8  
            && rect.width/rect.height < 1.2  
            && rect.height*rect.height*FLOAT > copy1->height*copy1->width  
            && rect.y < copy1->height-50  
            )  
        {  
            printf("rect.x = %d  rect.y = %d  rect.width = %d  rect.height = %d\n",rect.x,rect.y,rect.width,rect.height);  
            //rect.x-=10;  
           // rect.y-=10;  
           // rect.width+=20;  
           // rect.height+=20;  
            RECT[i] = rect; // 将图片中符合的矩形区域存到RECT  
            i++;  
        }  
        contours = contours->h_next;  
          
    }  
    printf("Find the bounding rect %d!\n", i);  
    for(j=0; j<i; j++)  
    {  
        if(j == 0)  
        {  
            cvRectangleR(copy1, RECT[j], CV_RGB(255, 0, 0), 3);  
            Rect[k] = RECT[j];  
            k++;  
            //printf("j = %d\n",j);  
            //printf("The j is the %d!\n",j);  
        }  
        else if(RECT[j-1].y - RECT[j].y > 100  
                || (RECT[j-1].x - RECT[j].x > 200  
                || RECT[j].x - RECT[j-1].x > 200))  
        {  
              cvRectangleR(copy1, RECT[j], CV_RGB(255,0,0), 3);  
              Rect[k] = RECT[j];  
              k++;  
              //printf("The jj is the %d!\n",j);  
        }  
    }  
      
    cvNamedWindow("4. copy1", 0);  
    cvShowImage("4. copy1", copy1);  
    //cvWaitKey(0);  
    //cvReleaseImage(&Grayimage);  
    cvReleaseImage(&temp);  
    cvReleaseImage(&threshold);  
    cvReleaseImage(&erode_dilate);  
    cvReleaseImage(&srcImage);  
    cvReleaseImage(&copy);  
    cvReleaseImage(&copy1);  
    // create a reader  
    //srcImage = cvLoadImage(argv[1],1);  
    srcImage = Grayimage; //解码图片必需位灰度图  
    ImageScanner scanner;  
  
    // configure the reader  
    scanner.set_config(ZBAR_NONE, ZBAR_CFG_ENABLE, 1);  
  
    // obtain image data  
       
    const void *raw = NULL;  
    //int width=srcImage->width;    
    //int height=srcImage->height;     
    //raw = srcImage->imageDataOrigin;  
    //cvMat(int rows, int cols, int type, void * data CV_DEFAULT(NULL))  
    //cout<<"The number is the one!"<<endl;  
	//
	uchar* raw_gray = (uchar*)imageGray.data;	
    int width = imageGray.cols;    
    int height=imageGray.rows;     
    // wrap image data  
    zbar::Image image(width, height, "Y800", raw_gray, width * height);  
  
    // scan the image for barcodes  
    int n = scanner.scan(image);  
     
    std::string strTemp="";  
    zbar::Image::SymbolIterator symbol = image.symbol_begin();  
    cout << "decoded " << symbol->get_type_name()<<endl;  
      
    for(; symbol != image.symbol_end(); ++symbol)   
    {  
            // do something useful with results  
            strTemp = strTemp + symbol->get_data() + ";";  
            cout << "decoded " << symbol->get_type_name()<< " symbol \"" << symbol->get_data() << '"' << endl;  
    }  
  
    // clean up  
    image.set_data(NULL, 0);  
      
    cvWaitKey(0);  
    cvReleaseImage(&Grayimage);  

    return(0);  
}  
