#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <zbar.h>
#include <cv.h>
#include <highgui.h>
#include <iostream>      
  
using namespace std;      
using namespace zbar;  //添加zbar名称空间    
using namespace cv;      
  
int main(int argc, char*argv[])    
{      
	if(argc != 2) {
		cout << "usage: qrdecoder <picture-name> " << endl;
		return 0;
	}
	//
	// 实例化扫描器对象,并配置
	//
    ImageScanner scanner;      
    scanner.set_config(ZBAR_NONE, ZBAR_CFG_ENABLE, 1);    
	//
	// 读取图片
	//
    Mat image = imread(argv[1]);      
    Mat imageGray;      
	//
	// 图像灰度化
	//
    cvtColor(image, imageGray, CV_RGB2GRAY);      
    int width = imageGray.cols;      
    int height = imageGray.rows;      
    uchar *raw = (uchar *)imageGray.data;         
	//
	// 实例化Image对象, 按照"Y800"格式构造
	// imageZbar 对象, 并讲图像数据传入该对象
	//
    Image imageZbar(width, height, "Y800", raw, width * height);        
	//
	// 调度扫描器扫描Image对象imageZber
	//
    scanner.scan(imageZbar); 
    Image::SymbolIterator symbol = imageZbar.symbol_begin();  
    if(imageZbar.symbol_begin() == imageZbar.symbol_end())  
    {  
        cout<<"扫码失败，请检查图片！"<<endl;  
    }  

    for(; symbol != imageZbar.symbol_end(); ++symbol)    
    {      
        cout << "二维码类型：" << endl << symbol->get_type_name() << endl << endl;    
        cout << "  数据信息：" << endl << symbol->get_data() << endl << endl;       
    }      
    imshow("XXDK Image", image);        
    waitKey();    
    imageZbar.set_data(NULL, 0);  

    return 0;  
}
